import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
const Color mainColor = Color(0xFF00B5B8);
Color secondColor = Color(0xFF6FD277);
const Color greyColor = Color(0xFFF5F5F5);
Color bgColor = Colors.white;
